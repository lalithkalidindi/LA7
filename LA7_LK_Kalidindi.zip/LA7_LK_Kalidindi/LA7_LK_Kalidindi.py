#-------------------------------------------------------------------------------
# Name: FirstName LastName
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines as set forth by the
# instructor and the class syllabus.
#-------------------------------------------------------------------------------
# References:
#-------------------------------------------------------------------------------
# Comments to grader:
#-------------------------------------------------------------------------------
# Code: Code starts here
# ------------------------------------------------------------------------------
# importing the tkinter 
from tkinter import *

# making a class called logicFrame
class LogicFrame(Frame):

    # making a init function
    def __init__(self, root):

        # making a init of frame
        Frame.__init__(self, root)

        # making a self of data
        self.data = StringVar(self, 'Please enter your details')

        # making a self of widgits
        self.create_widgets()

    # making a function of create_widgits
    def create_widgets(self):

        # making self of name 
        self.name = StringVar(self)

        # making self of department
        self.department = StringVar(self)

        # making self of eid
        self.eid = StringVar(self)

        # making self of address
        self.address = StringVar(self)

        # making a label of name
        self.label_name = Label(self, text="Name")

        # making a label of department
        self.label_department = Label(self, text="Department")

        # making a label of Employee ID
        self.label_eid = Label(self, text="Employee ID")

        # making a label of Address
        self.label_address = Label(self, text="Address")

        # making the entries
        self.entry_name = Entry(self, textvariable=self.name)  # names

        self.entry_department = Entry(self, textvariable=self.department)  # department

        self.entry_eid = Entry(self, textvariable=self.eid)  # eid

        self.entry_address = Entry(self, textvariable=self.address)  # address

        # making the labels
        self.label_name.grid(row=0, column=0, padx=5, pady=5, sticky=W)  # name

        self.label_department.grid(row=1, column=0, padx=5, pady=5, sticky=W)  # department

        self.label_eid.grid(row=2, column=0, padx=5, pady=5, sticky=W)  # eid

        self.label_address.grid(row=3, column=0, padx=5, pady=5, sticky=W)  # address

        # making the grid
        self.entry_name.grid(row=0, column=1, padx=5, pady=5)  # name

        self.entry_department.grid(row=1, column=1, padx=5, pady=5)  # department

        self.entry_eid.grid(row=2, column=1, padx=5, pady=5)  # eid

        self.entry_address.grid(row=3, column=1, padx=5, pady=5)  # address

        # creating the buttons
        self.button_add = Button(self, text="Add", command=self.add)  # add

        self.button_reset = Button(self, text="Reset", command=self.reset)  # reset

        # making the button grid for add
        self.button_add.grid(row=4, column=0, pady=10)  # add

        self.button_reset.grid(row=4, column=1, pady=10)  # reset

        # making the message label
        self.message_label = Label(self, textvariable=self.data)  # label

        self.message_label.grid(row=5, column=0, columnspan=2, pady=5)  # message label for grid

    # making the functon for add
    def add(self):

        # getting the name
        name = self.name.get()

        # getting the department
        department = self.department.get()

        # getting the eid
        eid = self.eid.get()

        # getting the address
        address = self.address.get()

        # making a file
        with open("employee.txt", "a") as file:
            file.write(f"{name},{department},{eid},{address}\n")  # the format of the text

        # makimg the display message
        self.data.set("Added Successfully")

    # making a function of the reset
    def reset(self):

        # resets the all of the name
        self.name.set("")

        # resets the all of the department
        self.department.set("")

        # resets the all of the eid
        self.eid.set("")

        # resets the all of the address
        self.address.set("")

        # displaying the reset message
        self.data.set("Reset Successfully")


# Create root window of Tk
root = Tk()

root.title("TK Practice")

# Create object
app = LogicFrame(root)

app.pack(padx=10, pady=10)

# runs the program
root.mainloop()
        
        

        
        
       
    
       
        
        
        
    
        
        
        
        

